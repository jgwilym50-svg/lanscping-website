/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['Playfair Display', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        green: {
          50:  '#f0f9f0',
          100: '#dcf0dc',
          200: '#bbe3bb',
          300: '#8fcf8f',
          400: '#5db55d',
          500: '#3a9a3a',
          600: '#2d7d2d',
          700: '#256325',
          800: '#1e4f1e',
          900: '#173f17',
          950: '#0c230c',
        },
        earth: {
          50:  '#faf7f2',
          100: '#f3ede0',
          200: '#e5d8c0',
          300: '#d4bf97',
          400: '#c0a16e',
          500: '#b08a52',
          600: '#9a7344',
          700: '#7f5c38',
          800: '#684b31',
          900: '#55402b',
          950: '#2e2015',
        },
        slate: {
          50:  '#f8fafc',
          100: '#f1f5f9',
          200: '#e2e8f0',
          300: '#cbd5e1',
          400: '#94a3b8',
          500: '#64748b',
          600: '#475569',
          700: '#334155',
          800: '#1e293b',
          900: '#0f172a',
          950: '#020617',
        },
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'slide-up': 'slideUp 0.7s ease-out forwards',
        'slide-in-left': 'slideInLeft 0.7s ease-out forwards',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideInLeft: {
          '0%': { opacity: '0', transform: 'translateX(-30px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
      },
    },
  },
  plugins: [],
};
