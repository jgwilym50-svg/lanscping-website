/*
  # Create contact_enquiries table

  ## Summary
  Creates a table to store website contact form submissions from Canterbury Green's website.

  ## New Tables
  - `contact_enquiries`
    - `id` (uuid, primary key) — unique identifier
    - `name` (text, required) — full name of the enquirer
    - `email` (text, required) — email address
    - `phone` (text, optional) — phone number
    - `suburb` (text, optional) — Christchurch suburb
    - `service` (text, optional) — service category of interest
    - `message` (text, required) — project description/enquiry
    - `created_at` (timestamptz) — submission timestamp

  ## Security
  - RLS enabled on `contact_enquiries`
  - Anonymous users (website visitors) may INSERT only
  - Authenticated admin users may SELECT all enquiries
*/

CREATE TABLE IF NOT EXISTS contact_enquiries (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL,
  email      text NOT NULL,
  phone      text,
  suburb     text,
  service    text,
  message    text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE contact_enquiries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit an enquiry"
  ON contact_enquiries
  FOR INSERT
  TO anon
  WITH CHECK (
    name  <> '' AND
    email <> '' AND
    message <> ''
  );

CREATE POLICY "Authenticated users can view enquiries"
  ON contact_enquiries
  FOR SELECT
  TO authenticated
  USING (true);
