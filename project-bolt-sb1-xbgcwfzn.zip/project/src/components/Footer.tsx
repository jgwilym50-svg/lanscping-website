import { Leaf, Phone, Mail, MapPin, Facebook, Instagram } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const handleNav = (page: string) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-5">
              <div className="p-1.5 bg-green-800 rounded-full">
                <Leaf className="w-5 h-5 text-green-300" strokeWidth={2.5} />
              </div>
              <div>
                <p className="font-serif font-semibold text-white text-lg leading-none">Canterbury Green</p>
                <p className="text-xs text-green-400 tracking-wider uppercase mt-0.5">Landscaping</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed text-slate-400 mb-6">
              Transforming outdoor spaces across Christchurch and the wider Canterbury region since 2008. Quality craftsmanship, sustainable practices.
            </p>
            <div className="flex gap-3">
              <a href="#" aria-label="Facebook" className="p-2 bg-slate-800 hover:bg-green-700 rounded-sm transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" aria-label="Instagram" className="p-2 bg-slate-800 hover:bg-green-700 rounded-sm transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">Quick Links</h3>
            <ul className="space-y-3">
              {['home', 'about', 'services', 'gallery', 'contact'].map((page) => (
                <li key={page}>
                  <button
                    onClick={() => handleNav(page)}
                    className="text-sm text-slate-400 hover:text-green-400 capitalize transition-colors"
                  >
                    {page}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">Services</h3>
            <ul className="space-y-3">
              {[
                'Garden Design',
                'Lawn Care & Maintenance',
                'Planting & Landscaping',
                'Decking & Paving',
                'Irrigation Systems',
                'Tree & Hedge Work',
              ].map((service) => (
                <li key={service}>
                  <button
                    onClick={() => handleNav('services')}
                    className="text-sm text-slate-400 hover:text-green-400 transition-colors text-left"
                  >
                    {service}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                <span className="text-sm text-slate-400">142 Riccarton Road,<br />Christchurch 8041, NZ</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-green-400 shrink-0" />
                <a href="tel:+6433801234" className="text-sm text-slate-400 hover:text-green-400 transition-colors">
                  (03) 380 1234
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-green-400 shrink-0" />
                <a href="mailto:hello@canterburygreen.co.nz" className="text-sm text-slate-400 hover:text-green-400 transition-colors">
                  hello@canterburygreen.co.nz
                </a>
              </li>
            </ul>
            <div className="mt-6 p-4 bg-slate-800 rounded-sm">
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-1">Business Hours</p>
              <p className="text-sm text-slate-300">Mon – Fri: 7:30am – 5:30pm</p>
              <p className="text-sm text-slate-300">Saturday: 8:00am – 2:00pm</p>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-slate-500">
            &copy; {new Date().getFullYear()} Canterbury Green Landscaping Ltd. All rights reserved.
          </p>
          <p className="text-xs text-slate-600">Christchurch, Canterbury, New Zealand</p>
        </div>
      </div>
    </footer>
  );
}
