import { useState, useEffect } from 'react';
import { Menu, X, Leaf } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

const navLinks = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'services', label: 'Services' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'contact', label: 'Contact' },
];

export default function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (id: string) => {
    onNavigate(id);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const isHome = currentPage === 'home';
  const transparent = isHome && !scrolled && !mobileOpen;

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        transparent
          ? 'bg-transparent'
          : 'bg-white/95 backdrop-blur-sm shadow-sm border-b border-slate-100'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <button
            onClick={() => handleNav('home')}
            className="flex items-center gap-2.5 group"
          >
            <div className={`p-1.5 rounded-full transition-colors ${transparent ? 'bg-white/20' : 'bg-green-50'}`}>
              <Leaf
                className={`w-5 h-5 transition-colors ${transparent ? 'text-white' : 'text-green-600'}`}
                strokeWidth={2.5}
              />
            </div>
            <div className="flex flex-col leading-none">
              <span className={`font-serif font-semibold text-lg tracking-tight transition-colors ${transparent ? 'text-white' : 'text-slate-900'}`}>
                Canterbury Green
              </span>
              <span className={`text-xs font-light tracking-wider uppercase transition-colors ${transparent ? 'text-white/70' : 'text-green-600'}`}>
                Landscaping
              </span>
            </div>
          </button>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNav(link.id)}
                className={`px-4 py-2 text-sm font-medium rounded-sm transition-all duration-200 relative group ${
                  currentPage === link.id
                    ? transparent
                      ? 'text-white'
                      : 'text-green-700'
                    : transparent
                    ? 'text-white/80 hover:text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {link.label}
                <span
                  className={`absolute bottom-0 left-4 right-4 h-0.5 rounded-full transition-all duration-200 ${
                    currentPage === link.id
                      ? 'bg-green-500 opacity-100'
                      : 'bg-green-500 opacity-0 group-hover:opacity-40'
                  }`}
                />
              </button>
            ))}
            <button
              onClick={() => handleNav('contact')}
              className={`ml-4 px-5 py-2.5 text-sm font-medium rounded-sm transition-all duration-200 active:scale-95 ${
                transparent
                  ? 'bg-white/20 backdrop-blur-sm text-white border border-white/40 hover:bg-white/30'
                  : 'bg-green-600 text-white hover:bg-green-700 shadow-sm'
              }`}
            >
              Get a Quote
            </button>
          </nav>

          {/* Mobile toggle */}
          <button
            className={`md:hidden p-2 rounded-sm transition-colors ${transparent ? 'text-white' : 'text-slate-700'}`}
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 shadow-lg">
          <nav className="max-w-7xl mx-auto px-4 py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNav(link.id)}
                className={`text-left px-4 py-3 text-sm font-medium rounded-sm transition-colors ${
                  currentPage === link.id
                    ? 'bg-green-50 text-green-700'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => handleNav('contact')}
              className="mt-2 w-full bg-green-600 text-white py-3 px-4 text-sm font-medium rounded-sm hover:bg-green-700 transition-colors"
            >
              Get a Free Quote
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
