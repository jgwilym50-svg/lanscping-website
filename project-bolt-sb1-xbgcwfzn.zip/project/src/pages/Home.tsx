import { ArrowRight, CheckCircle, Star, ChevronDown } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

const stats = [
  { value: '16+', label: 'Years Experience' },
  { value: '850+', label: 'Projects Completed' },
  { value: '100%', label: 'Client Satisfaction' },
  { value: '30+', label: 'Team Members' },
];

const services = [
  {
    title: 'Garden Design',
    description: 'Bespoke garden designs tailored to your lifestyle, soil type, and Canterbury climate.',
    img: 'https://images.pexels.com/photos/1453499/pexels-photo-1453499.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    title: 'Lawn Care',
    description: 'Professional mowing, aeration, fertilisation, and seasonal lawn programmes.',
    img: 'https://images.pexels.com/photos/589840/pexels-photo-589840.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    title: 'Decking & Paving',
    description: 'Timber decks, stone patios, and outdoor living areas built to last.',
    img: 'https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];

const testimonials = [
  {
    name: 'Sarah Mitchell',
    suburb: 'Fendalton',
    stars: 5,
    text: 'Canterbury Green completely transformed our backyard. The team was professional, on time, and the finished result exceeded our expectations.',
  },
  {
    name: 'James & Fiona Carr',
    suburb: 'Merivale',
    stars: 5,
    text: 'We\'ve used them for three years now for our garden maintenance. Reliable, knowledgeable, and great communication throughout.',
  },
  {
    name: 'David Huang',
    suburb: 'Cashmere',
    stars: 5,
    text: 'The new deck and planting scheme they designed for us is stunning. Neighbours stop to comment on it regularly!',
  },
];

export default function Home({ onNavigate }: HomeProps) {
  const handleNav = (page: string) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1453499/pexels-photo-1453499.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Beautiful garden landscape"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900/80 via-slate-800/60 to-green-900/50" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-8 animate-fade-in">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-white/90 text-sm font-medium">Christchurch's Trusted Landscapers Since 2008</span>
          </div>

          <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-semibold text-white mb-6 leading-tight animate-slide-up">
            Your Dream Garden,
            <br />
            <span className="text-green-400">Brought to Life</span>
          </h1>

          <p className="text-xl text-white/80 mb-10 max-w-2xl mx-auto leading-relaxed animate-slide-up">
            Canterbury's premier landscaping company. From bespoke garden designs to full outdoor transformations — we craft spaces that thrive in the New Zealand climate.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <button onClick={() => handleNav('contact')} className="btn-primary text-base px-8 py-4">
              Get a Free Quote <ArrowRight className="w-5 h-5" />
            </button>
            <button onClick={() => handleNav('gallery')} className="btn-outline text-base px-8 py-4">
              View Our Work
            </button>
          </div>
        </div>

        <button
          onClick={() => window.scrollTo({ top: window.innerHeight, behavior: 'smooth' })}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/60 hover:text-white transition-colors animate-bounce"
          aria-label="Scroll down"
        >
          <ChevronDown className="w-8 h-8" />
        </button>
      </section>

      {/* Stats */}
      <section className="bg-green-700 py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="font-serif text-4xl md:text-5xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-green-200 text-sm font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Intro */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-green-600 text-sm font-semibold uppercase tracking-widest mb-3">What We Do</p>
            <h2 className="section-title mb-4">Expert Landscaping Services</h2>
            <p className="section-subtitle mx-auto text-center">
              From initial concept to final plant, we handle every aspect of your outdoor space.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service) => (
              <div key={service.title} className="card group">
                <div className="relative overflow-hidden h-56">
                  <img
                    src={service.img}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                </div>
                <div className="p-6">
                  <h3 className="font-serif text-xl font-semibold text-slate-900 mb-2">{service.title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed mb-4">{service.description}</p>
                  <button
                    onClick={() => handleNav('services')}
                    className="text-green-600 text-sm font-medium hover:text-green-700 inline-flex items-center gap-1 transition-colors group-hover:gap-2"
                  >
                    Learn more <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button onClick={() => handleNav('services')} className="btn-outline-dark">
              All Services <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-green-600 text-sm font-semibold uppercase tracking-widest mb-3">Why Canterbury Green</p>
              <h2 className="section-title mb-6">Local Expertise,<br />Lasting Results</h2>
              <p className="text-slate-500 leading-relaxed mb-8">
                We know Canterbury's soil, climate, and growing seasons intimately. Our team of qualified horticulturalists and landscape designers brings that local knowledge to every project — big or small.
              </p>
              <ul className="space-y-4">
                {[
                  'Fully licensed and insured',
                  'Canterbury-native plant specialists',
                  'Transparent, itemised quotes',
                  'Post-project care and support',
                  'Sustainable and eco-friendly practices',
                  'NZILA member company',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600 shrink-0" />
                    <span className="text-slate-700 text-sm">{item}</span>
                  </li>
                ))}
              </ul>
              <button onClick={() => handleNav('about')} className="btn-primary mt-10">
                About Our Company <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1072824/pexels-photo-1072824.jpeg?auto=compress&cs=tinysrgb&w=900"
                alt="Landscaping team at work"
                className="rounded-sm w-full h-96 object-cover shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-green-700 text-white p-6 rounded-sm shadow-xl hidden lg:block">
                <p className="font-serif text-3xl font-bold">16+</p>
                <p className="text-green-200 text-sm">Years serving<br />Christchurch</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-green-600 text-sm font-semibold uppercase tracking-widest mb-3">Client Stories</p>
            <h2 className="section-title mb-4">What Our Clients Say</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((t) => (
              <div key={t.name} className="bg-slate-50 p-8 rounded-sm border border-slate-100">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.stars }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-slate-600 text-sm leading-relaxed mb-6 italic">"{t.text}"</p>
                <div>
                  <p className="font-semibold text-slate-900 text-sm">{t.name}</p>
                  <p className="text-slate-400 text-xs">{t.suburb}, Christchurch</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Beautiful garden"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-green-900/80" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-6">
            Ready to Transform Your Outdoor Space?
          </h2>
          <p className="text-green-200 text-lg mb-10 leading-relaxed">
            Get in touch today for a free, no-obligation consultation. We'll visit your property and provide a detailed quote.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => handleNav('contact')} className="btn-primary text-base px-8 py-4">
              Request a Free Quote <ArrowRight className="w-5 h-5" />
            </button>
            <button onClick={() => handleNav('gallery')} className="btn-outline text-base px-8 py-4">
              Browse Projects
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
