import { ArrowRight, Award, Users, Leaf, Heart } from 'lucide-react';

interface AboutProps {
  onNavigate: (page: string) => void;
}

const team = [
  {
    name: 'Tom Whitfield',
    role: 'Founder & Head Designer',
    bio: 'With a degree in Landscape Architecture from Lincoln University, Tom founded Canterbury Green with a vision to create exceptional outdoor spaces across the region.',
    img: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    name: 'Rachel O\'Brien',
    role: 'Senior Horticulturalist',
    bio: 'Rachel specialises in native Canterbury planting and sustainable garden ecology. She has 12 years of hands-on experience in residential and commercial projects.',
    img: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    name: 'Mark Stevenson',
    role: 'Construction Team Lead',
    bio: 'Mark oversees all hardscaping, decking and paving projects, bringing 15 years of building and landscaping construction expertise to every job.',
    img: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    name: 'Priya Desai',
    role: 'Irrigation Specialist',
    bio: 'Priya is a certified irrigation designer who creates efficient, water-smart systems that keep Canterbury gardens thriving through hot summers and frosts.',
    img: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
];

const values = [
  {
    icon: Award,
    title: 'Quality Craftsmanship',
    desc: 'We never cut corners. Every project is delivered to the highest standard, using premium materials suited to Canterbury conditions.',
  },
  {
    icon: Leaf,
    title: 'Sustainability',
    desc: 'We champion native planting, water-efficient design, and environmentally responsible practices in everything we do.',
  },
  {
    icon: Users,
    title: 'Community',
    desc: 'Canterbury is home. We actively support local suppliers, apprentice programmes, and community green spaces.',
  },
  {
    icon: Heart,
    title: 'Client Care',
    desc: 'Your outdoor space is personal. We listen carefully, communicate clearly, and take pride in exceeding expectations.',
  },
];

export default function About({ onNavigate }: AboutProps) {
  const handleNav = (page: string) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1072824/pexels-photo-1072824.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Team in the garden"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/85 via-slate-900/60 to-slate-900/30" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-green-400 text-sm font-semibold uppercase tracking-widest mb-4">About Us</p>
            <h1 className="font-serif text-5xl md:text-6xl font-semibold text-white mb-6 leading-tight">
              Rooted in Canterbury<br />Since 2008
            </h1>
            <p className="text-white/80 text-lg leading-relaxed">
              Canterbury Green was built on a simple belief: every outdoor space deserves thoughtful design and expert care. Over 16 years, we've grown into one of Christchurch's most respected landscaping companies.
            </p>
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-green-600 text-sm font-semibold uppercase tracking-widest mb-3">Our Story</p>
              <h2 className="section-title mb-6">How It All Began</h2>
              <div className="space-y-4 text-slate-600 leading-relaxed">
                <p>
                  Canterbury Green was founded in 2008 by Tom Whitfield, a Lincoln University graduate who wanted to bring professional, ecologically thoughtful landscaping to Christchurch homeowners. Starting with a ute, a trailer, and a small team of two, Tom built the company project by project.
                </p>
                <p>
                  After the 2011 earthquakes, Canterbury Green played a meaningful role in helping rebuild and beautify the city — restoring gardens, replanting streetscapes, and transforming damaged sections into new green spaces.
                </p>
                <p>
                  Today, our team of 30+ landscape professionals handles everything from small residential gardens to large commercial and civic projects. We remain a family-owned Christchurch business, deeply proud of the city we call home.
                </p>
              </div>
              <button onClick={() => handleNav('services')} className="btn-primary mt-8">
                Explore Our Services <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Garden project"
                className="rounded-sm h-56 w-full object-cover"
              />
              <img
                src="https://images.pexels.com/photos/1453499/pexels-photo-1453499.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Planting"
                className="rounded-sm h-56 w-full object-cover mt-8"
              />
              <img
                src="https://images.pexels.com/photos/589840/pexels-photo-589840.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Lawn care"
                className="rounded-sm h-56 w-full object-cover"
              />
              <img
                src="https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Decking"
                className="rounded-sm h-56 w-full object-cover mt-8"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-green-600 text-sm font-semibold uppercase tracking-widest mb-3">What Drives Us</p>
            <h2 className="section-title mb-4">Our Values</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((v) => (
              <div key={v.title} className="text-center p-8 bg-white rounded-sm border border-slate-100 hover:shadow-md transition-shadow">
                <div className="inline-flex items-center justify-center w-14 h-14 bg-green-50 rounded-full mb-5">
                  <v.icon className="w-7 h-7 text-green-600" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-slate-900 mb-3">{v.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <p className="text-green-600 text-sm font-semibold uppercase tracking-widest mb-3">The People Behind the Projects</p>
            <h2 className="section-title mb-4">Meet Our Team</h2>
            <p className="section-subtitle mx-auto text-center">
              Qualified, passionate, and deeply knowledgeable about Canterbury's unique environment.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member) => (
              <div key={member.name} className="group">
                <div className="relative overflow-hidden rounded-sm mb-4 h-72">
                  <img
                    src={member.img}
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-slate-900">{member.name}</h3>
                <p className="text-green-600 text-sm font-medium mb-2">{member.role}</p>
                <p className="text-slate-500 text-sm leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Accreditations */}
      <section className="py-16 bg-green-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-green-200 text-sm font-semibold uppercase tracking-widest mb-6">Accreditations & Memberships</p>
          <div className="flex flex-wrap justify-center gap-x-12 gap-y-4">
            {[
              'New Zealand Institute of Landscape Architects',
              'Registered Master Builders',
              'NZ Certified Landscapers',
              'Green Building Council NZ',
            ].map((a) => (
              <span key={a} className="text-white font-medium text-sm">{a}</span>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title mb-4">Let's Build Something Beautiful</h2>
          <p className="section-subtitle mx-auto mb-8 text-center">
            Contact our team for a free consultation and personalised quote.
          </p>
          <button onClick={() => handleNav('contact')} className="btn-primary text-base px-8 py-4">
            Get in Touch <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>
    </div>
  );
}
