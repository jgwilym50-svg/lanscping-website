import { ArrowRight, Check } from 'lucide-react';

interface ServicesProps {
  onNavigate: (page: string) => void;
}

const services = [
  {
    id: 'design',
    title: 'Garden Design',
    tagline: 'From concept to creation',
    description:
      'Our qualified landscape architects and designers create tailored garden plans that reflect your lifestyle and complement your home. We consider soil type, sun, water, and Canterbury climate in every design.',
    img: 'https://images.pexels.com/photos/1453499/pexels-photo-1453499.jpeg?auto=compress&cs=tinysrgb&w=900',
    includes: [
      'Site assessment and consultation',
      'Concept drawings and 3D renders',
      'Planting plans with native species',
      'Hardscaping layout and materials selection',
      'Project management and installation',
    ],
  },
  {
    id: 'lawn',
    title: 'Lawn Care & Maintenance',
    tagline: 'Year-round care for a perfect lawn',
    description:
      'Regular lawn maintenance keeps your garden looking its best through all four Canterbury seasons. We offer one-off visits or ongoing maintenance packages for residential and commercial properties.',
    img: 'https://images.pexels.com/photos/589840/pexels-photo-589840.jpeg?auto=compress&cs=tinysrgb&w=900',
    includes: [
      'Weekly and fortnightly mowing',
      'Edging, blowing and tidy-up',
      'Fertilisation programmes',
      'Aeration and dethatching',
      'Weed and pest control',
    ],
  },
  {
    id: 'planting',
    title: 'Planting & Landscaping',
    tagline: 'The right plant in the right place',
    description:
      'We source premium natives, exotics, and seasonal plants to bring colour, texture, and life to your garden. Our horticulturalists select species proven to thrive in Christchurch conditions.',
    img: 'https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=900',
    includes: [
      'Planting design and species selection',
      'Native and eco-friendly options',
      'Seasonal colour planting',
      'Mulching and soil preparation',
      'Establishment care and watering',
    ],
  },
  {
    id: 'decking',
    title: 'Decking & Paving',
    tagline: 'Outdoor living, built to last',
    description:
      'Extend your living space with beautiful timber decks, stone patios, and paved areas. Our construction team uses quality materials and expert craftsmanship to create outdoor spaces you\'ll love for decades.',
    img: 'https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg?auto=compress&cs=tinysrgb&w=900',
    includes: [
      'Timber and composite decking',
      'Stone, brick and concrete paving',
      'Retaining walls and steps',
      'Pergolas and shade structures',
      'Outdoor kitchens and fire pits',
    ],
  },
  {
    id: 'irrigation',
    title: 'Irrigation Systems',
    tagline: 'Smart watering for Canterbury summers',
    description:
      'Canterbury\'s hot, dry summers demand reliable irrigation. Our certified irrigation designers create efficient, automated systems that keep your garden healthy while minimising water use.',
    img: 'https://images.pexels.com/photos/1072824/pexels-photo-1072824.jpeg?auto=compress&cs=tinysrgb&w=900',
    includes: [
      'System design and consultation',
      'Drip and spray irrigation',
      'Automated timer and smart controller setup',
      'Seasonal adjustments and servicing',
      'Rainwater harvesting integration',
    ],
  },
  {
    id: 'trees',
    title: 'Tree & Hedge Work',
    tagline: 'Safe, skilled arboricultural care',
    description:
      'From pruning to removal, our arboricultural team handles all tree and hedge work safely and professionally. We work with council requirements and have the equipment for large-scale jobs.',
    img: 'https://images.pexels.com/photos/957024/forest-trees-perspective-bright-957024.jpeg?auto=compress&cs=tinysrgb&w=900',
    includes: [
      'Tree pruning and shaping',
      'Hedge trimming and reshaping',
      'Tree removal and stump grinding',
      'Council consent applications',
      'Storm damage response',
    ],
  },
];

export default function Services({ onNavigate }: ServicesProps) {
  const handleNav = (page: string) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Landscaping services"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/85 via-slate-900/60 to-slate-900/30" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-green-400 text-sm font-semibold uppercase tracking-widest mb-4">What We Offer</p>
            <h1 className="font-serif text-5xl md:text-6xl font-semibold text-white mb-6 leading-tight">
              Our Services
            </h1>
            <p className="text-white/80 text-lg leading-relaxed">
              Comprehensive landscaping solutions for Christchurch homes and businesses. Whatever your outdoor space needs, we've got the expertise to deliver.
            </p>
          </div>
        </div>
      </section>

      {/* Service navigation pills */}
      <div className="sticky top-16 md:top-20 z-40 bg-white border-b border-slate-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1 overflow-x-auto py-3 scrollbar-hide">
            {services.map((s) => (
              <a
                key={s.id}
                href={`#${s.id}`}
                className="shrink-0 px-4 py-1.5 text-xs font-medium rounded-full bg-slate-100 hover:bg-green-100 hover:text-green-700 text-slate-600 transition-colors"
              >
                {s.title}
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Services */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {services.map((service, i) => (
          <section
            key={service.id}
            id={service.id}
            className={`py-24 ${i < services.length - 1 ? 'border-b border-slate-100' : ''}`}
          >
            <div className={`grid lg:grid-cols-2 gap-16 items-center ${i % 2 === 1 ? 'lg:grid-flow-col' : ''}`}>
              <div className={i % 2 === 1 ? 'lg:order-2' : ''}>
                <p className="text-green-600 text-sm font-medium uppercase tracking-widest mb-2">{service.tagline}</p>
                <h2 className="font-serif text-3xl md:text-4xl font-semibold text-slate-900 mb-4">{service.title}</h2>
                <p className="text-slate-500 leading-relaxed mb-8">{service.description}</p>
                <ul className="space-y-3 mb-8">
                  {service.includes.map((item) => (
                    <li key={item} className="flex items-center gap-3">
                      <span className="flex-shrink-0 w-5 h-5 bg-green-100 rounded-full flex items-center justify-center">
                        <Check className="w-3 h-3 text-green-700" strokeWidth={3} />
                      </span>
                      <span className="text-slate-700 text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
                <button onClick={() => handleNav('contact')} className="btn-primary">
                  Get a Quote <ArrowRight className="w-4 h-4" />
                </button>
              </div>
              <div className={i % 2 === 1 ? 'lg:order-1' : ''}>
                <img
                  src={service.img}
                  alt={service.title}
                  className="w-full h-96 object-cover rounded-sm shadow-lg"
                />
              </div>
            </div>
          </section>
        ))}
      </div>

      {/* CTA */}
      <section className="bg-slate-900 py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-4xl font-semibold text-white mb-4">
            Not Sure What You Need?
          </h2>
          <p className="text-slate-400 text-lg mb-8">
            Contact us for a free site visit and we'll recommend the best approach for your garden.
          </p>
          <button onClick={() => handleNav('contact')} className="btn-primary text-base px-8 py-4">
            Book a Free Consultation <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>
    </div>
  );
}
