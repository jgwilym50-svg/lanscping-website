import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

const services = [
  'Garden Design',
  'Lawn Care & Maintenance',
  'Planting & Landscaping',
  'Decking & Paving',
  'Irrigation Systems',
  'Tree & Hedge Work',
  'Other',
];

type FormState = 'idle' | 'submitting' | 'success' | 'error';

export default function Contact() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    suburb: '',
    service: '',
    message: '',
  });
  const [formState, setFormState] = useState<FormState>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormState('submitting');
    setErrorMsg('');

    const { error } = await supabase.from('contact_enquiries').insert({
      name: form.name,
      email: form.email,
      phone: form.phone || null,
      suburb: form.suburb || null,
      service: form.service || null,
      message: form.message,
    });

    if (error) {
      setErrorMsg('Something went wrong. Please try again or call us directly.');
      setFormState('error');
    } else {
      setFormState('success');
      setForm({ name: '', email: '', phone: '', suburb: '', service: '', message: '' });
    }
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1030940/pexels-photo-1030940.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Contact us"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/85 via-slate-900/60 to-slate-900/30" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-green-400 text-sm font-semibold uppercase tracking-widest mb-4">Get in Touch</p>
            <h1 className="font-serif text-5xl md:text-6xl font-semibold text-white mb-6 leading-tight">
              Let's Talk About<br />Your Garden
            </h1>
            <p className="text-white/80 text-lg leading-relaxed">
              Ready to transform your outdoor space? Contact us for a free, no-obligation quote. We'll get back to you within one business day.
            </p>
          </div>
        </div>
      </section>

      {/* Main content */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Contact info */}
            <div className="lg:col-span-1 space-y-8">
              <div>
                <h2 className="font-serif text-2xl font-semibold text-slate-900 mb-6">Contact Details</h2>
                <ul className="space-y-6">
                  <li className="flex items-start gap-4">
                    <div className="p-2.5 bg-green-100 rounded-sm shrink-0">
                      <Phone className="w-5 h-5 text-green-700" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-1">Phone</p>
                      <a href="tel:+6433801234" className="text-slate-800 font-medium hover:text-green-700 transition-colors">
                        (03) 380 1234
                      </a>
                    </div>
                  </li>
                  <li className="flex items-start gap-4">
                    <div className="p-2.5 bg-green-100 rounded-sm shrink-0">
                      <Mail className="w-5 h-5 text-green-700" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-1">Email</p>
                      <a href="mailto:hello@canterburygreen.co.nz" className="text-slate-800 font-medium hover:text-green-700 transition-colors break-all">
                        hello@canterburygreen.co.nz
                      </a>
                    </div>
                  </li>
                  <li className="flex items-start gap-4">
                    <div className="p-2.5 bg-green-100 rounded-sm shrink-0">
                      <MapPin className="w-5 h-5 text-green-700" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-1">Address</p>
                      <p className="text-slate-800 font-medium">142 Riccarton Road<br />Christchurch 8041, NZ</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-4">
                    <div className="p-2.5 bg-green-100 rounded-sm shrink-0">
                      <Clock className="w-5 h-5 text-green-700" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-1">Hours</p>
                      <p className="text-slate-800 font-medium">Mon – Fri: 7:30am – 5:30pm</p>
                      <p className="text-slate-800 font-medium">Saturday: 8:00am – 2:00pm</p>
                    </div>
                  </li>
                </ul>
              </div>

              <div className="p-6 bg-green-700 rounded-sm text-white">
                <h3 className="font-serif text-lg font-semibold mb-3">Service Area</h3>
                <p className="text-green-200 text-sm leading-relaxed mb-4">
                  We service all suburbs of Christchurch city and the wider Canterbury region, including Selwyn, Waimakariri, and Banks Peninsula.
                </p>
                <p className="text-green-200 text-sm">Unsure if we cover your area? Just ask!</p>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-2">
              <div className="bg-white p-8 md:p-10 rounded-sm border border-slate-100 shadow-sm">
                <h2 className="font-serif text-2xl font-semibold text-slate-900 mb-2">Request a Free Quote</h2>
                <p className="text-slate-500 text-sm mb-8">Fill in the form below and we'll be in touch within one business day.</p>

                {formState === 'success' ? (
                  <div className="text-center py-12">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                      <CheckCircle className="w-8 h-8 text-green-600" />
                    </div>
                    <h3 className="font-serif text-2xl font-semibold text-slate-900 mb-2">Message Received!</h3>
                    <p className="text-slate-500 mb-6">Thank you for getting in touch. Our team will respond within one business day.</p>
                    <button
                      onClick={() => setFormState('idle')}
                      className="btn-outline-dark"
                    >
                      Send Another Message
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2" htmlFor="name">
                          Full Name *
                        </label>
                        <input
                          id="name"
                          name="name"
                          type="text"
                          required
                          value={form.name}
                          onChange={handleChange}
                          placeholder="Jane Smith"
                          className="w-full px-4 py-3 border border-slate-200 rounded-sm text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2" htmlFor="email">
                          Email Address *
                        </label>
                        <input
                          id="email"
                          name="email"
                          type="email"
                          required
                          value={form.email}
                          onChange={handleChange}
                          placeholder="jane@example.com"
                          className="w-full px-4 py-3 border border-slate-200 rounded-sm text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                        />
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2" htmlFor="phone">
                          Phone Number
                        </label>
                        <input
                          id="phone"
                          name="phone"
                          type="tel"
                          value={form.phone}
                          onChange={handleChange}
                          placeholder="021 123 4567"
                          className="w-full px-4 py-3 border border-slate-200 rounded-sm text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2" htmlFor="suburb">
                          Suburb
                        </label>
                        <input
                          id="suburb"
                          name="suburb"
                          type="text"
                          value={form.suburb}
                          onChange={handleChange}
                          placeholder="Fendalton"
                          className="w-full px-4 py-3 border border-slate-200 rounded-sm text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2" htmlFor="service">
                        Service Required
                      </label>
                      <select
                        id="service"
                        name="service"
                        value={form.service}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-slate-200 rounded-sm text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all bg-white"
                      >
                        <option value="">Select a service...</option>
                        {services.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2" htmlFor="message">
                        Tell Us About Your Project *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        required
                        rows={5}
                        value={form.message}
                        onChange={handleChange}
                        placeholder="Describe your garden, what you'd like done, approximate size, any specific requirements..."
                        className="w-full px-4 py-3 border border-slate-200 rounded-sm text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all resize-none"
                      />
                    </div>

                    {formState === 'error' && (
                      <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-sm text-red-700 text-sm">
                        <AlertCircle className="w-5 h-5 shrink-0" />
                        {errorMsg}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={formState === 'submitting'}
                      className="w-full btn-primary justify-center py-4 text-base disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                      {formState === 'submitting' ? (
                        <>
                          <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          Send Message
                        </>
                      )}
                    </button>

                    <p className="text-xs text-slate-400 text-center">
                      We respect your privacy. Your details will never be shared with third parties.
                    </p>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="h-80 bg-slate-200 relative overflow-hidden">
        <img
          src="https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Canterbury region"
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-white/90 backdrop-blur-sm px-8 py-6 rounded-sm shadow-lg text-center">
            <p className="font-serif text-xl font-semibold text-slate-900">Christchurch, Canterbury</p>
            <p className="text-slate-500 text-sm mt-1">Serving all suburbs and the wider Canterbury region</p>
          </div>
        </div>
      </section>
    </div>
  );
}
