import { useState } from 'react';
import { X, ZoomIn } from 'lucide-react';

interface GalleryProps {
  onNavigate: (page: string) => void;
}

const categories = ['All', 'Garden Design', 'Lawn Care', 'Decking & Paving', 'Planting', 'Irrigation'];

const projects = [
  {
    id: 1,
    title: 'Fendalton Family Garden',
    category: 'Garden Design',
    suburb: 'Fendalton',
    description: 'A complete redesign featuring native plantings, a central lawn and entertaining deck.',
    img: 'https://images.pexels.com/photos/1453499/pexels-photo-1453499.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'large',
  },
  {
    id: 2,
    title: 'Merivale Lawn Renovation',
    category: 'Lawn Care',
    suburb: 'Merivale',
    description: 'Full lawn renovation including soil remediation, re-seeding and irrigation.',
    img: 'https://images.pexels.com/photos/589840/pexels-photo-589840.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'medium',
  },
  {
    id: 3,
    title: 'Cashmere Hillside Terrace',
    category: 'Decking & Paving',
    suburb: 'Cashmere',
    description: 'Multi-level terraced garden with natural stone paving and timber deck.',
    img: 'https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'large',
  },
  {
    id: 4,
    title: 'St Albans Native Garden',
    category: 'Planting',
    suburb: 'St Albans',
    description: 'A low-maintenance native planting scheme with seasonal interest year-round.',
    img: 'https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'medium',
  },
  {
    id: 5,
    title: 'Riccarton Smart Irrigation',
    category: 'Irrigation',
    suburb: 'Riccarton',
    description: 'Smart drip irrigation system covering 1,200m² of gardens with automated control.',
    img: 'https://images.pexels.com/photos/1072824/pexels-photo-1072824.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'medium',
  },
  {
    id: 6,
    title: 'Burnside Entertainer\'s Garden',
    category: 'Garden Design',
    suburb: 'Burnside',
    description: 'Outdoor kitchen, fire pit, lawn and lush planting for the ultimate entertainer.',
    img: 'https://images.pexels.com/photos/2449452/pexels-photo-2449452.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'large',
  },
  {
    id: 7,
    title: 'Papanui Cottage Garden',
    category: 'Planting',
    suburb: 'Papanui',
    description: 'A romantic English-inspired cottage garden with roses, lavender and box hedging.',
    img: 'https://images.pexels.com/photos/1416367/pexels-photo-1416367.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'medium',
  },
  {
    id: 8,
    title: 'Redwood Modern Deck',
    category: 'Decking & Paving',
    suburb: 'Redwood',
    description: 'Contemporary hardwood deck with integrated seating, planters and lighting.',
    img: 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'medium',
  },
  {
    id: 9,
    title: 'Halswell Estate Garden',
    category: 'Garden Design',
    suburb: 'Halswell',
    description: 'Award-winning formal garden design for a character property on 2,500m².',
    img: 'https://images.pexels.com/photos/1030940/pexels-photo-1030940.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'large',
  },
  {
    id: 10,
    title: 'Shirley Sports Turf',
    category: 'Lawn Care',
    suburb: 'Shirley',
    description: 'Commercial-grade sports turf installation and ongoing maintenance for a community facility.',
    img: 'https://images.pexels.com/photos/209958/pexels-photo-209958.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'medium',
  },
  {
    id: 11,
    title: 'Sumner Coastal Planting',
    category: 'Planting',
    suburb: 'Sumner',
    description: 'Wind and salt-tolerant coastal planting scheme for a beachside property.',
    img: 'https://images.pexels.com/photos/775201/pexels-photo-775201.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'medium',
  },
  {
    id: 12,
    title: 'Ilam Japanese Garden',
    category: 'Garden Design',
    suburb: 'Ilam',
    description: 'Serene Japanese-inspired garden with stone lanterns, moss, raked gravel and maples.',
    img: 'https://images.pexels.com/photos/2990644/pexels-photo-2990644.jpeg?auto=compress&cs=tinysrgb&w=900',
    size: 'large',
  },
];

interface ModalProject {
  id: number;
  title: string;
  category: string;
  suburb: string;
  description: string;
  img: string;
  size: string;
}

export default function Gallery({ onNavigate }: GalleryProps) {
  const [activeCategory, setActiveCategory] = useState('All');
  const [modalProject, setModalProject] = useState<ModalProject | null>(null);

  const filtered = activeCategory === 'All'
    ? projects
    : projects.filter((p) => p.category === activeCategory);

  const handleNav = (page: string) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/2449452/pexels-photo-2449452.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Gallery hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/85 via-slate-900/60 to-slate-900/20" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-green-400 text-sm font-semibold uppercase tracking-widest mb-4">Our Portfolio</p>
            <h1 className="font-serif text-5xl md:text-6xl font-semibold text-white mb-6 leading-tight">
              Project Gallery
            </h1>
            <p className="text-white/80 text-lg leading-relaxed">
              Browse our portfolio of completed landscaping projects across Christchurch and Canterbury. Every project tells a unique story.
            </p>
          </div>
        </div>
      </section>

      {/* Filter */}
      <div className="bg-white border-b border-slate-100 sticky top-16 md:top-20 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`shrink-0 px-4 py-2 text-sm font-medium rounded-full transition-all duration-200 ${
                  activeCategory === cat
                    ? 'bg-green-600 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Grid */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
            {filtered.map((project) => (
              <div
                key={project.id}
                className="break-inside-avoid group relative overflow-hidden rounded-sm cursor-pointer shadow-sm hover:shadow-xl transition-all duration-300"
                onClick={() => setModalProject(project)}
              >
                <img
                  src={project.img}
                  alt={project.title}
                  className={`w-full object-cover group-hover:scale-105 transition-transform duration-500 ${
                    project.size === 'large' ? 'h-72' : 'h-52'
                  }`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <span className="text-xs text-green-300 font-medium uppercase tracking-wider">{project.category}</span>
                    <h3 className="font-serif text-lg font-semibold text-white mt-1">{project.title}</h3>
                    <p className="text-white/70 text-xs mt-1">{project.suburb}, Christchurch</p>
                  </div>
                  <div className="absolute top-4 right-4">
                    <div className="bg-white/20 backdrop-blur-sm p-2 rounded-full">
                      <ZoomIn className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-24">
              <p className="text-slate-400">No projects found in this category.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-white py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title mb-4">Inspired by What You See?</h2>
          <p className="section-subtitle mx-auto mb-8 text-center">
            Let us create something just as special for your property. Get in touch for a free consultation.
          </p>
          <button onClick={() => handleNav('contact')} className="btn-primary text-base px-8 py-4">
            Start Your Project
          </button>
        </div>
      </section>

      {/* Lightbox Modal */}
      {modalProject && (
        <div
          className="fixed inset-0 z-[100] bg-black/85 flex items-center justify-center p-4"
          onClick={() => setModalProject(null)}
        >
          <div
            className="bg-white rounded-sm max-w-3xl w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <img
                src={modalProject.img}
                alt={modalProject.title}
                className="w-full h-72 md:h-96 object-cover"
              />
              <button
                className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 p-2 rounded-full text-white transition-colors"
                onClick={() => setModalProject(null)}
              >
                <X className="w-5 h-5" />
              </button>
              <span className="absolute bottom-4 left-4 bg-green-600 text-white text-xs font-medium px-3 py-1 rounded-full">
                {modalProject.category}
              </span>
            </div>
            <div className="p-6">
              <h3 className="font-serif text-2xl font-semibold text-slate-900 mb-1">{modalProject.title}</h3>
              <p className="text-green-600 text-sm font-medium mb-3">{modalProject.suburb}, Christchurch</p>
              <p className="text-slate-500 leading-relaxed">{modalProject.description}</p>
              <button
                onClick={() => { setModalProject(null); handleNav('contact'); }}
                className="mt-6 btn-primary"
              >
                Enquire About This Style
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
